const Log = require("../models/Log");
const detectErrorSpike = require("../utils/analyzer");

exports.createLog = async (req, res) => {
  const log = await Log.create(req.body);
  await detectErrorSpike();
  res.json(log);
};

exports.getLogs = async (req, res) => {
  const { level } = req.query;
  let query = {};
  if (level) query.level = level;
  const logs = await Log.find(query).sort({ timestamp: -1 });
  res.json(logs);
};