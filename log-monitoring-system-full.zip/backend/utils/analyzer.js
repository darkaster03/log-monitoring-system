const Log = require("../models/Log");
const detectErrorSpike = async () => {
  const lastMinute = new Date(Date.now() - 60000);
  const count = await Log.countDocuments({
    level: "ERROR",
    timestamp: { $gte: lastMinute }
  });
  if (count > 5) console.log("⚠️ Error spike detected!");
};
module.exports = detectErrorSpike;