async function fetchLogs() {
  const level = document.getElementById("level").value;
  let url = "http://localhost:5000/api/logs";
  if (level) url += "?level=" + level;

  const res = await fetch(url);
  const data = await res.json();

  const table = document.getElementById("logTable");
  table.innerHTML = "<tr><th>Level</th><th>Message</th><th>Service</th><th>Time</th></tr>";

  data.forEach(log => {
    const row = `<tr>
      <td>${log.level}</td>
      <td>${log.message}</td>
      <td>${log.service}</td>
      <td>${new Date(log.timestamp).toLocaleString()}</td>
    </tr>`;
    table.innerHTML += row;
  });
}