# Log Monitoring & Debugging System

## Features
- Log ingestion API
- Filtering logs
- Error spike detection
- Simple dashboard UI

## Run Backend
cd backend
npm install
node server.js

## Run Frontend
Open frontend/index.html in browser

## API Example
POST /api/logs
{
 "level":"ERROR",
 "message":"API failed",
 "service":"payment"
}
